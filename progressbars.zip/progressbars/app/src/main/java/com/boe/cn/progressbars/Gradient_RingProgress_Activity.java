package com.boe.cn.progressapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 *
 */
public class Gradient_RingProgress_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gradient__ring_progress_);
    }
}
